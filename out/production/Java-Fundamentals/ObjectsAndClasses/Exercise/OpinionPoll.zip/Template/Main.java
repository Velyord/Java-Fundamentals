/*
Task:

*/
package Template;

import static Template.NumberValidator.setNumber;
import static Template.StringValidator.setText;
import static Template.PersonalUtils.*;
import static java.lang.System.out;

public class Main {
    public static void main(String[] args) {

    }
}